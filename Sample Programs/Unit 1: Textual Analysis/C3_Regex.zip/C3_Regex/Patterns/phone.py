import re
phone = r'^(?:\((\d{3})\))?(\d{3})[-.](\d{4})$'
m = re.match(phone,'(949)824-2704')
assert m != None, 'No match'
print(m.groups())
area, exchange, number = [int(i) if i != None else None for i in m.group(1,2,3)]
print(area, exchange, number)
