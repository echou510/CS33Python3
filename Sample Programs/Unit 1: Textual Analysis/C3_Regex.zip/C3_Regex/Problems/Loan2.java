public class Loan {
  private double annual_interest_rate;
  private int number_of_years;
  private double loan_amount;
  private java.util.Date loan_date;

  /** Default constructor */
  public Loan() {
    this(2.5, 1, 1000);
  }

  /** Construct a loan with specified annual interest rate,
      number of years, and loan amount
    */
  public Loan(double annual_interest_rate, int number_of_years,
      double loan_amount) {
    this.annual_interest_rate = annual_interest_rate;
    this.number_of_years = number_of_years;
    this.loan_amount = loan_amount;
    loan_date = new java.util.Date();
  }

  /** Return annual_interest_rate */
  public double get_annual_interest_rate() {
    return annual_interest_rate;
  }

  /** Set a new annual_interest_rate */
  public void set_annual_interest_rate(double annual_interest_rate) {
    this.annual_interest_rate = annual_interest_rate;
  }

  /** Return number_of_years */
  public int get_number_of_years() {
    return number_of_years;
  }

  /** Set a new number_of_years */
  public void set_number_of_years(int number_of_years) {
    this.number_of_years = number_of_years;
  }

  /** Return loan_amount */
  public double get_loan_amount() {
    return loan_amount;
  }

  /** Set a newloan_amount */
  public void set_loan_amount(double loan_amount) {
    this.loan_amount = loan_amount;
  }

  /** Find monthly payment */
  public double get_monthly_payment() {
    double monthly_interest_rate = annual_interest_rate / 1200;
    double monthly_payment = loan_amount * monthly_interest_rate / (1 -
      (1 / Math.pow(1 + monthly_interest_rate, number_of_years * 12)));
    return monthly_payment;    
  }

  /** Find total payment */
  public double get_total_payment() {
    double total_payment = get_monthly_payment() * number_of_years * 12;
    return total_payment;    
  }

  /** Return loan date */
  public java.util.Date get_loan_date() {
    return loan_date;
  }
}