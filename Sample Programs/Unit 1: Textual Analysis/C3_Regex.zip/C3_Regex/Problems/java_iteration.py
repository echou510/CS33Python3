import re

line="aaa javaVariable uuu computer science zzz variableA yyy floatingNumber sss initialVariableValue"
p=re.compile("[a-z]+([A-Z][a-z0-9_]*)+")     # + is used instead of *
pos=0
m=p.search(line, pos)
while m:
    start = m.start()
    pos = m.end()
    leng = m.span()[1] - m.span()[0]  # length of the variable
    print("Now search start position :", start, pos, leng)
    print(m.group())
    m=p.search(line, pos)
