# goal.py
# string substitue (replace)
import re

def contract(v):
    v = re.sub(r"go+al", "goal", v)
    return v

v = contract("goal gooal gooooooal goooooooal goooooooooal gooal!! gooooooal!! gooal!!!")
print(v)
