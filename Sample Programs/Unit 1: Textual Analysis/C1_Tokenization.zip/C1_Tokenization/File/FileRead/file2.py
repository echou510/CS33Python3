# file2.py
# on token per line case
# line is actually also a token
f  = open("aa.txt", "r")
lines = f.readlines()
for line in lines:
    line = line.strip()
    print(line, end=" ")
f.close()
