# file5.py
# read the whole file into a list of line strings
f  = open("aa.txt", "r")
lines = f.readlines()
print("Print file list format: ")
print(lines)

all_lines = ""
for line in lines:
    all_lines += line

print("Print file as a long string: ")
print(all_lines)
f.close()