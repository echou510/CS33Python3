# file3.py
# read the whole file into a string
# and, split the string into a list of tokens
f  = open("aa.txt", "r")
tokens = f.read().split()
for token in tokens:
    token = token.strip()
    print("Token: ", token)
f.close()