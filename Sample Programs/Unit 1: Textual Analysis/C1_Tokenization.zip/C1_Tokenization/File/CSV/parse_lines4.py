# parse_lines3.py
# read a csv file and print the student record to screen.
#
def parse_lines(open_file, sep, conversions):
    for line in open_file:
        yield [conv(item) for conv,item in
                  zip(conversions,line.rstrip('\n').split(sep))]

for fields in parse_lines(open("Student.csv"),",",(str, lambda scores : [int(q) for q in scores.split(":")],int)):
    print(fields)


