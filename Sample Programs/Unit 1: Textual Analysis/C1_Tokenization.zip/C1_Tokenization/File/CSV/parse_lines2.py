# parse_lines2.py
# read a csv file and print the student record to screen.
#
def parse_lines(open_file, sep, conversions):
    for line in open_file:
        yield [conv(item) for conv,item in
                  zip(conversions,line.rstrip('\n').split(sep))]

for name,test1,test2 in parse_lines(open("Student.csv"),',',(str,int,int)):
    print(name, (test1+test2)/2)

