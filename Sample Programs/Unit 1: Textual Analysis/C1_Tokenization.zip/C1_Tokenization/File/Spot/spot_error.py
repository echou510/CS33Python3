# spot.py:
# bugs on examples 2, 8, 7 form teacher of ICS 33
def process(word):
    print(word)

print("\n\nExample 1:")
for line in open('file.txt'):
    for word in line.rstrip().lower().split():
        process(word)

# erroneous lower to a list
print("\n\nExample 2:")
for line in open('file.txt'):
    for word in line.rstrip().split().lower():
        process(word)

print("\n\nExample 3:")
for line in open('file.txt'):
    for word in line.lower().rstrip().split():
        process(word)

# erroneous rstrip to a list
print("\n\nExample 4:")
for line in open('file.txt'):
    for word in line.lower().split().rstrip():
        process(word)

# erroneous rstrip/lower to a list
print("\n\nExample 5:")
for line in open('file.txt'):
    for word in line.split().rstrip().lower():
        process(word)

# erroneous rstrip/lower to a list
print("\n\nExample 6:")
for line in open('file.txt'):
    for word in line.split().lower().rstrip():
        process(word)

# word not generated
print("\n\nExample 7:")
for line in open('file.txt').read().lower().split('\n'):
    process(word)

# word not generated
print("\n\nExample 8:")
for line in open('file.txt').read().split('\n').lower():
    process(word)
